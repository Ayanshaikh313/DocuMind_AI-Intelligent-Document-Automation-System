// TestAdder.java
import java.util.Scanner;

class Adder {
    double a, b, c;

    // First constructor: two arguments
    Adder(double n1, double n2) {
        this.a = n1;
        this.b = n2;
    }

    // Second constructor: three arguments
    Adder(double n1, double n2, double n3) {
        this.a = n1;
        this.b = n2;
        this.c = n3;
    }

    // First method: adds two variables
    double add() {
        return a + b;
    }

    // Second overloaded method: adds three variables
    double add(double n1, double n2, double n3) {
        return n1 + n2 + n3;
    }
}

public class TestAdder {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter three double values (n1, n2, n3):");
        double n1 = sc.nextDouble();
        double n2 = sc.nextDouble();
        double n3 = sc.nextDouble();

        Adder obj1 = new Adder(n1, n2);

       
        double result1 = obj1.add();
        System.out.println("Result of adding two values using obj1: " + result1);

       
        Adder obj2 = new Adder(n1, n2, n3);

        
        double result2 = obj2.add(obj2.a, obj2.b, obj2.c);
        System.out.println("Result of adding three values using obj2: " + result2);
        sc.close();
    }
}

Enter three double values (n1, n2, n3):
10.2
14.3
23.5
Result of adding two values using obj1: 24.5
Result of adding three values using obj2: 48.0