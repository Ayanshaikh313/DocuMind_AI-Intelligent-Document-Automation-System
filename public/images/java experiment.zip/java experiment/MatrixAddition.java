import java.util.Scanner;

class MatrixAddition {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input rows and columns of first matrix
        System.out.print("Enter rows and columns of first matrix: ");
        int r1 = sc.nextInt();
        int c1 = sc.nextInt();

        // Input rows and columns of second matrix
        System.out.print("Enter rows and columns of second matrix: ");
        int r2 = sc.nextInt();
        int c2 = sc.nextInt();

        // Check if addition possible
        if (r1 != r2 || c1 != c2) {
            System.out.println("Addition cannot be done due to size mismatch!");
            return;
        }

        int[][] arr1 = new int[r1][c1];
        int[][] arr2 = new int[r2][c2];
        int[][] arr3 = new int[r1][c1]; // result

        // Input first matrix
        System.out.println("Enter elements of first matrix:");
        for (int i = 0; i < r1; i++) {
            for (int j = 0; j < c1; j++) {
                arr1[i][j] = sc.nextInt();
            }
        }

        // Input second matrix
        System.out.println("Enter elements of second matrix:");
        for (int i = 0; i < r2; i++) {
            for (int j = 0; j < c2; j++) {
                arr2[i][j] = sc.nextInt();
            }
        }

        // Perform addition
        for (int i = 0; i < r1; i++) {
            for (int j = 0; j < c1; j++) {
                arr3[i][j] = arr1[i][j] + arr2[i][j];
            }
        }

        // Display first matrix
        System.out.println("\nFirst Matrix:");
        for (int i = 0; i < r1; i++) {
            for (int j = 0; j < c1; j++) {
                System.out.print(arr1[i][j] + " ");
            }
            System.out.println();
        }

        // Display second matrix
        System.out.println("\nSecond Matrix:");
        for (int i = 0; i < r2; i++) {
            for (int j = 0; j < c2; j++) {
                System.out.print(arr2[i][j] + " ");
            }
            System.out.println();
        }

        // Display result matrix
        System.out.println("\nResultant Matrix after Addition:");
        for (int i = 0; i < r1; i++) {
            for (int j = 0; j < c1; j++) {
                System.out.print(arr3[i][j] + " ");
            }
            System.out.println();
        }

        sc.close();
    }
}

Enter rows and columns of first matrix: 3 3
Enter rows and columns of second matrix: 3 3
Enter elements of first matrix:
1 2 3 4 5 6 7 8 9
Enter elements of second matrix:
 2 1 3 6 4 5 9 7 8

First Matrix:
1 2 3
4 5 6
7 8 9

Second Matrix:
2 1 3
6 4 5
9 7 8

Resultant Matrix after Addition:
3 3 6
10 9 11
16 15 17
