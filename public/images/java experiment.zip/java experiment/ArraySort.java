import java.util.*;

class ArraySort {
    // Method to sort integer array
    public int[] sortIntArray(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    // swap
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
        return arr;
    }

    // Method to sort String array
    public String[] sortStrArray(String[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j].compareTo(arr[j + 1]) > 0) {
                    // swap
                    String temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
        return arr;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArraySort sorter = new ArraySort();

        // Integer array input
        System.out.print("Enter size of integer array: ");
        int n = sc.nextInt();
        int[] intArr = new int[n];
        System.out.println("Enter integer elements:");
        for (int i = 0; i < n; i++) {
            intArr[i] = sc.nextInt();
        }

        // String array input
        System.out.print("Enter size of string array: ");
        int m = sc.nextInt();
        sc.nextLine(); // consume newline
        String[] strArr = new String[m];
        System.out.println("Enter string elements:");
        for (int i = 0; i < m; i++) {
            strArr[i] = sc.nextLine();
        }

        // Sorting using custom methods
        int[] intArrSort = sorter.sortIntArray(intArr.clone());
        String[] strArrSort = sorter.sortStrArray(strArr.clone());

        // Sorting using Arrays.sort()
        int[] intArrLib = intArr.clone();
        String[] strArrLib = strArr.clone();
        Arrays.sort(intArrLib);
        Arrays.sort(strArrLib);

        // Display results
        System.out.println("\nOriginal Integer Array: " + Arrays.toString(intArr));
        System.out.println("Sorted using custom method: " + Arrays.toString(intArrSort));
        System.out.println("Sorted using Arrays.sort(): " + Arrays.toString(intArrLib));

        System.out.println("\nOriginal String Array: " + Arrays.toString(strArr));
        System.out.println("Sorted using custom method: " + Arrays.toString(strArrSort));
        System.out.println("Sorted using Arrays.sort(): " + Arrays.toString(strArrLib));

        sc.close();
    }
}

Enter size of integer array: 6
Enter integer elements:
2 5 8 9 6 4
Enter size of string array: 5
Enter string elements:
omkar
siddhesh
shubham
ganesh
nilesh

Original Integer Array: [2, 5, 8, 9, 6, 4]
Sorted using custom method: [2, 4, 5, 6, 8, 9]
Sorted using Arrays.sort(): [2, 4, 5, 6, 8, 9]

Original String Array: [omkar, siddhesh, shubham, ganesh, nilesh]
Sorted using custom method: [ganesh, nilesh, omkar, shubham, siddhesh]
Sorted using Arrays.sort(): [ganesh, nilesh, omkar, shubham, siddhesh]
