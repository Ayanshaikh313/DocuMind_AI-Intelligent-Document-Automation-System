import java.util.Scanner;

class Calculator {

    // Method to compute factorial
    public static long factorial(int n) {
        long fact = 1;
        for (int i = 1; i <= n; i++) {
            fact *= i;
        }
        return fact;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char cont;

        do {
            // Accept two numbers
            System.out.print("Enter first number: ");
            double a = sc.nextDouble();

            System.out.print("Enter second number: ");
            double b = sc.nextDouble();

            // Display operations
            System.out.println("\nChoose operation:");
            System.out.println("1. Add");
            System.out.println("2. Subtract");
            System.out.println("3. Multiply");
            System.out.println("4. Divide");
            System.out.println("5. Factorial (of first number only)");

            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Result = " + (a + b));
                    break;
                case 2:
                    System.out.println("Result = " + (a - b));
                    break;
                case 3:
                    System.out.println("Result = " + (a * b));
                    break;
                case 4:
                    if (b != 0)
                        System.out.println("Result = " + (a / b));
                    else
                        System.out.println("Error: Division by zero!");
                    break;
                case 5:
                    if (a >= 0 && a == (int)a)  // factorial only for non-negative integers
                        System.out.println("Factorial of " + (int)a + " = " + factorial((int)a));
                    else
                        System.out.println("Factorial not defined for given input!");
                    break;
                default:
                    System.out.println("Incorrect Choice!");
            }

            // Ask user to continue
            System.out.print("\nDo you want to continue? (Y/N): ");
            cont = sc.next().charAt(0);

        } while (cont == 'Y' || cont == 'y');

        System.out.println("Calculator closed.");
        sc.close();
    }
}


Enter first number: 10
Enter second number: 24

Choose operation:
1. Add
2. Subtract
3. Multiply
4. Divide
5. Factorial (of first number only)
Enter your choice: 1
Result = 34.0

Do you want to continue? (Y/N): Y
Enter first number: 10
Enter second number: 24

Choose operation:
1. Add
2. Subtract
3. Multiply
4. Divide
5. Factorial (of first number only)
Enter your choice: 2
Result = -14.0

Do you want to continue? (Y/N): Y
Enter first number: 10
Enter second number: 24

Choose operation:
1. Add
2. Subtract
3. Multiply
4. Divide
5. Factorial (of first number only)
Enter your choice: 3
Result = 240.0

Do you want to continue? (Y/N): Y
Enter first number: 10
Enter second number: 24

Choose operation:
1. Add
2. Subtract
3. Multiply
4. Divide
5. Factorial (of first number only)
Enter your choice: 4
Result = 0.4166666666666667

Do you want to continue? (Y/N): Y
Enter first number: 5
Enter second number: 2

Choose operation:
1. Add
2. Subtract
3. Multiply
4. Divide
5. Factorial (of first number only)
Enter your choice: 5
Factorial of 5 = 120

Do you want to continue? (Y/N):
