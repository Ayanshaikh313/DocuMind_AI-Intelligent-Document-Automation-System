Name   : Walse Omkar Vilas
Roll No: 304C040

EXPERIMENT NO:-01

import java.util.Scanner;

class Factorial {
    // Method to compute factorial
    public int computeFactorial(int n) {
        int fact = 1;
        for (int i = 1; i <= n; i++) {
            fact *= i;
        }
        return fact;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Factorial obj = new Factorial();

        System.out.print("Enter a number: ");
        int N = sc.nextInt();

        int result = obj.computeFactorial(N);
        System.out.println("Factorial of " + N + " is: " + result);

        sc.close();
    }
}


output :-
Enter a number: 5
Factorial of 5 is: 120
