import java.util.Scanner;

// Rectangle class
class Rectangle {
    double width, length, area;
    String color;

    // Parameterized constructor
    Rectangle(double width, double length, String color) {
        this.width = width;
        this.length = length;
        this.color = color;
    }

    // Method to calculate area
    double rectArea() {
        area = width * length;
        return area;
    }
}

// Main class
class CheckRectangles {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Taking input for first rectangle
        System.out.println("Enter width, length and color of first rectangle:");
        double w1 = sc.nextDouble();
        double l1 = sc.nextDouble();
        String c1 = sc.next();

        Rectangle r1 = new Rectangle(w1, l1, c1);

        // Taking input for second rectangle
        System.out.println("Enter width, length and color of second rectangle:");
        double w2 = sc.nextDouble();
        double l2 = sc.nextDouble();
        String c2 = sc.next();

        Rectangle r2 = new Rectangle(w2, l2, c2);

        // Displaying results
        System.out.println("\nArea of first rectangle = " + r1.rectArea() + " , Color = " + r1.color);
        System.out.println("Area of second rectangle = " + r2.rectArea() + " , Color = " + r2.color);

        // Comparing rectangles
        if (r1.rectArea() == r2.rectArea() && r1.color.equalsIgnoreCase(r2.color)) {
            System.out.println("Both rectangles are equal in area and color.");
        } else {
            System.out.println("Rectangles are different.");
        }

        sc.close();
    }
}


Enter width, length and color of first rectangle:
15
20
red
Enter width, length and color of second rectangle:
10
30
red

Area of first rectangle = 300.0 , Color = red
Area of second rectangle = 300.0 , Color = red
Both rectangles are equal in area and color.
