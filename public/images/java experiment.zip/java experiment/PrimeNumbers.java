import java.util.Scanner;

class PrimeNumbers {
    // Method to check if a number is prime
    public boolean isPrime(int num) {
        if (num <= 1) return false;
        for (int i = 2; i <= num / 2; i++) {
            if (num % i == 0) return false;
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PrimeNumbers obj = new PrimeNumbers();

        System.out.print("Enter how many prime numbers you want: ");
        int n = sc.nextInt();

        int count = 0, num = 2;
        System.out.println("First " + n + " prime numbers are:");

        while (count < n) {
            if (obj.isPrime(num)) {
                System.out.print(num + " ");
                count++;
            }
            num++;
        }

        sc.close();
    }
}

Enter how many prime numbers you want: 50
First 50 prime numbers are:
2 3 5 7 11 13 17 19 23 29 31 37 41 43 
47 53 59 61 67 71 73 79 83 89 97 101
103 107 109 113 127 131 137 139 149 
151 157 163 167 173 179 181 191 193
197 199 211 223 227 229